"""Whitelist de fontes, filtros e métricas permitidos pela API genérica."""

MESES_PT = [
    "janeiro",
    "fevereiro",
    "março",
    "abril",
    "maio",
    "junho",
    "julho",
    "agosto",
    "setembro",
    "outubro",
    "novembro",
    "dezembro",
]

BI_REGISTRY = {
    "zootecnico": {
        "schema": "zootecnico", "table": "vw_desempenho_acerto",
        "source_tables": ["acerto_lote_resultado_geral", "galpoes", "base_dinamica"],
        "min_year": 2023, "updated_column": "carregado_em",
        "date_column": "data_abate", "date_kind": "timestamp",
        "rules_version": "acerto-2026-10-05",
        "filters": {
            "ano": {"kind":"date_year", "column":"data_abate", "date_kind":"timestamp", "order":"desc"},
            "mes": {"kind":"date_month", "column":"data_abate", "date_kind":"timestamp"},
            "status_acerto": {"kind":"text", "column":"status_acerto"},
            "tipo_granja": {"kind":"text", "column":"tipo_granja"},
            "modelo": {"kind":"text", "column":"modelo"},
            "produtor": {"kind":"text", "column":"integrado"},
            "tecnico": {"kind":"text", "column":"tecnico_exibicao"},
            "galpao": {"kind":"text", "column":"gal"},
            "tipo_linhagem": {"kind":"lineage_type", "column":"linh"},
            "linhagem": {"kind":"text", "column":"linh"},
        },
        "metrics": {
            "iep": {"column":"iep", "numeric_kind":"typed", "name":"IEP", "decimals":2, "aggregation":"avg"},
            "cac": {"column":"cac", "numeric_kind":"typed", "name":"CAC", "decimals":3, "aggregation":"weighted_avg", "weight":"aloj", "weight_numeric_kind":"typed", "null_policy":"valid_pairs"},
            "ca": {"formula":{"numerator":"consumo_racao", "denominator":"pes_total"}, "numeric_kind":"typed", "name":"CA", "decimals":3, "aggregation":"ratio_sums"},
            "gmd": {"formula":{"numerator":{"numerator":"pes_total","denominator":"qt_aves"}, "denominator":{"numerator":"ida","denominator":"qt_aves","multiply":"qt_aves"}, "scale":1000}, "numeric_kind":"typed", "name":"GPD", "unit":"g/dia", "decimals":2, "aggregation":"ratio_sums"},
            "mortalidade": {"formula":{"numerator":"mort", "denominator":"aloj", "scale":100}, "numeric_kind":"typed", "name":"% Mortalidade", "unit":"%", "decimals":2, "aggregation":"ratio_sums"},
            "idade": {"formula":{"numerator":"ida", "denominator":"qt_aves", "multiply":"qt_aves"}, "numeric_kind":"typed", "name":"Idade Média", "unit":"dias", "decimals":2, "aggregation":"ratio_sums"},
            "peso_medio": {"formula":{"numerator":"pes_total", "denominator":"qt_aves"}, "numeric_kind":"typed", "name":"Peso Médio", "unit":"kg/ave", "decimals":3, "aggregation":"ratio_sums"},
            "vazio": {"column":"vazio_sanitario", "numeric_kind":"typed", "name":"Vazio", "unit":"dias", "decimals":2, "aggregation":"weighted_avg", "weight":"qt_aves", "weight_numeric_kind":"typed", "null_policy":"valid_pairs"},
            "morte_transporte": {"column":"mort_transporte_2", "name":"% Morte no Transporte", "unit":"%", "decimals":2, "aggregation":"weighted_avg", "weight":"aloj", "weight_numeric_kind":"typed", "null_policy":"valid_pairs"},
            "cac_ref": {"column":"cac_ref", "name":"CAC Ref", "decimals":3, "aggregation":"weighted_avg", "weight":"aloj", "weight_numeric_kind":"typed", "null_policy":"valid_pairs"},
            "aves_abatidas": {"column":"qt_aves", "numeric_kind":"typed", "name":"Aves Abatidas", "unit":"aves", "decimals":0, "aggregation":"sum"},
        },
        "metric_order": ["iep","ca","cac","gmd","mortalidade","idade","peso_medio","vazio","morte_transporte","cac_ref","aves_abatidas"],
        "ranking_columns": {"tecnicos":"tecnico", "produtores":"produtor"},
    }
}

# Configuração declarativa das fontes analíticas. Não contém credenciais.
COHORT_COLUMNS = {
    "id": "id", "codigo": "codigo_granja", "produtor": "nome_granja",
    "lote": "num_lote", "galpao": "galp", "recepcao": "data_recepcao",
    "ano": "ano", "semana": "semana_ano", "modelo": "modelo_aviario",
    "tipo_granja": "tipo_granja", "tecnico": "tecnico", "linhagem": "linhagem",
    "aves": "aves_inicia", "pinto": "ps_pinto", "versao": "periodo_fim",
    "atualizado": "carregado_em",
}
for week in (7,14,21,28,35,42):
    COHORT_COLUMNS[f"mort{week}"] = f"qtde_mort_sem_{week:02}"
    COHORT_COLUMNS[f"disc{week}"] = f"qtde_desc_sem_{week:02}"
    COHORT_COLUMNS[f"peso{week}"] = f"peso_med_{week:02}"

COHORT_FILTERS = {key: {"kind": "text", "column": key} for key in
                  ("tipo_granja", "produtor", "modelo", "galpao", "tecnico", "linhagem", "mist_linha")}
BI_REGISTRY["lotes-abertos"] = {
    "engine": "cohort", "schema": "zootecnico", "table": "mortalidade_peso_abertos",
    "columns": dict(COHORT_COLUMNS), "filters": {**COHORT_FILTERS, "periodo_dias": {"kind":"text", "column":"periodo_dias"}},
    "weeks": [7,14,21,28,35,42], "age_window": [0,45],
    "dedup": ["codigo","lote","galpao","recepcao"],
    "group_by": ["tipo_granja","produtor","linhagem"],
    "rules_version": "lotes-abertos-2026-10-01",
}
BI_REGISTRY["historico-fechados"] = {
    "engine": "cohort", "schema": "zootecnico", "table": "mortalidade_peso_fechados",
    "columns": {**COHORT_COLUMNS, "peso_abate": "ps_abate", "abate": "data_abate"},
    "filters": {**COHORT_FILTERS, "ano": {"kind":"year", "column":"ano"}},
    "calendar": {"column":"abate", "min_year":2023, "max_year":"current"},
    "weeks": [7,14,21,28,35], "group_by": ["semana","produtor","galpao"],
    "hierarchy": ["semana","produtor","galpao"],
    "dedup": ["codigo","lote","galpao","recepcao"],
    "rules_version": "historico-fechados-2026-10-02",
}
BI_REGISTRY["rxp"] = {
    "engine": "records", "schema": "zootecnico",
    "sources": [
        {"table":"lotes_planejados_abate_ave_nova", "label":"AVE NOVA"},
        {"table":"lotes_planejados_abate_real_alimentos", "label":"REAL ALIMENTOS"},
    ],
    "columns": {"id":"id", "data":"data", "codigo":"codigo", "produtor":"integrado",
                "galpao":"galpao", "lote":"lote", "tipo_granja":"tipo_granja", "modelo":"modelo_aviario",
                "destino":"destino", "programada":"qtde_programada", "real":"qtde_real",
                "difQtdeRxP":"dif_qtde_rxp", "atualizado":"carregado_em"},
    "filters": {key:{"kind":"text", "column":key} for key in
                ("data","unidade","destino","produtor","galpao","tecnico","tipo_granja","modelo")},
    "numeric": ["programada","real","difQtdeRxP"],
    "summary": {"programada":{"aggregation":"sum","column":"programada"},
                "real":{"aggregation":"sum","column":"real"},
                "diferenca":{"aggregation":"sum","column":"difQtdeRxP"},
                "registrosComDiferenca":{"aggregation":"count_nonzero","column":"difQtdeRxP"}},
    "ratio": {"id":"difPercent","numerator":"diferenca","denominator":"programada","scale":100},
    "group_by": ["unidade"],
    "technician_lookup": {"schema":"zootecnico","table":"base_dinamica","code":"cod_prod",
                          "name":"produtor","technician":"tecnico","date":"data_de_abate",
                          "tie_dates":["periodo_fim","carregado_em"],"id":"id"},
    "rules_version": "rxp-2026-10-01",
}
