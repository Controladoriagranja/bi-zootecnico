"""Capacidades analíticas no servidor, configuradas pelo registry.

Não lê arquivos locais; todas as fontes são consultas PostgreSQL de leitura.
Os registros são processados no servidor; só agregados/páginas chegam ao browser.
"""
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo
from collections import defaultdict
import json
import re
import unicodedata
from fastapi import HTTPException
from psycopg import sql

WEEKS = (7,14,21,28,35,42)


def number(value):
    if value is None: return None
    raw = str(value).strip()
    if not re.fullmatch(r"[+-]?[0-9]+([.,][0-9]+)?", raw): return None
    try: return Decimal(raw.replace(",", "."))
    except InvalidOperation: return None


def as_date(value):
    if isinstance(value, datetime): return value.date()
    if isinstance(value, date): return value
    raw = str(value or "").strip()
    try:
        if re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}([ T].*)?", raw): return date.fromisoformat(raw[:10])
        if re.fullmatch(r"[0-9]{2}/[0-9]{2}/[0-9]{4}", raw): return datetime.strptime(raw, "%d/%m/%Y").date()
    except ValueError: pass
    return None


def text(value): return str(value or "").strip()

def normal_name(value): return " ".join(unicodedata.normalize("NFKC", text(value)).casefold().split())

def ratio(numerator, denominator, scale=1):
    return numerator / denominator * scale if denominator else None

def sum_column(rows, key): return sum((number(r.get(key)) or Decimal(0) for r in rows), Decimal(0))

def mean(values):
    values = [v for v in values if v is not None]
    return sum(values, Decimal(0)) / len(values) if values else None


def fetch_rows(conn, config, table=None):
    columns = config["columns"]
    fields = sql.SQL(", ").join(sql.SQL("{} AS {}").format(sql.Identifier(col),sql.Identifier(alias)) for alias,col in columns.items())
    query = sql.SQL("SELECT {} FROM {} ORDER BY id").format(fields,sql.Identifier(config["schema"],table or config["table"]))
    return [dict(r) for r in conn.execute(query).fetchall()]


def bind_technicians(rows, history, spec):
    by_code = defaultdict(list)
    by_name = defaultdict(list)
    identities = defaultdict(set)
    for row in history:
        code, name = text(row.get(spec["code"])), normal_name(row.get(spec["name"]))
        if name: identities[name].add(code or "name:"+name)
        if not text(row.get(spec["technician"])) or not as_date(row.get(spec["date"])): continue
        if code: by_code[code].append(row)
        if name: by_name[name].append(row)
    def latest(items):
        # Campos do schema normalizado; id fornece desempate determinístico.
        return max(items, key=lambda r: (as_date(r.get(spec["date"])), *(text(r.get(k)) for k in spec["tie_dates"]), int(r.get(spec["id"]) or 0))) if items else None
    for row in rows:
        name = normal_name(row.get("produtor"))
        match = latest(by_code.get(text(row.get("codigo")), []))
        link = "codigo" if match else "sem_vinculo"
        if not match and len(identities.get(name, set())) == 1:
            match = latest(by_name.get(name, []))
            if match: link = "nome_exato"
        row["tecnico"] = text(match.get(spec["technician"])) if match else "Sem técnico vinculado"
        row["tecnico_data"] = as_date(match.get(spec["date"])).isoformat() if match else None
        row["tecnico_vinculo"] = link


def prepare_rows(conn, config, reference):
    if config.get("sources"):
        rows = []
        for source in config["sources"]:
            part = fetch_rows(conn, config, source["table"])
            for r in part:
                r["fonte"] = source["table"]
                r["unidade"] = source["label"]
            rows.extend(part)
        for r in rows:
            parsed = as_date(r.get("data"))
            r["data"] = parsed.isoformat() if parsed else None
            for key in config.get("numeric",[]): r[key] = number(r.get(key))
            r["difPercent"] = ratio(r.get("difQtdeRxP"), r.get("programada"), 100) if r.get("difQtdeRxP") is not None else None
        rows = [r for r in rows if all(text(r.get(k)) for k in ("data","produtor","galpao","lote"))]
        spec = config.get("technician_lookup")
        if spec:
            needed = list(dict.fromkeys([spec["code"],spec["name"],spec["technician"],spec["date"],*spec["tie_dates"],spec["id"]]))
            q = sql.SQL("SELECT {} FROM {}").format(sql.SQL(", ").join(map(sql.Identifier,needed)),sql.Identifier(spec["schema"],spec["table"]))
            bind_technicians(rows, [dict(r) for r in conn.execute(q).fetchall()], spec)
        return rows
    rows = fetch_rows(conn,config)
    latest = {}
    for index,r in enumerate(rows):
        arrival = as_date(r.get("recepcao"))
        r["recepcao"] = arrival.isoformat() if arrival else None
        keys = [text(r.get(k)) for k in config["dedup"]]
        key = tuple(keys) if all(keys) else ("incomplete",index)
        previous = latest.get(key)
        order = (as_date(r.get("versao")) or date.min,int(r.get("id") or 0))
        if not previous or order >= previous[0]: latest[key] = (order,r)
    rows = [r for _,r in latest.values()]
    for r in rows:
        arrival = as_date(r.get("recepcao"))
        r["idade"] = (reference-arrival).days if arrival else None
        r["mist_linha"] = "Mista" if "/" in text(r.get("linhagem")) else "Pura"
        for key in ["aves","pinto","peso_abate",*[f"{p}{w}" for p in ("mort","disc","peso") for w in config["weeks"]]]:
            if key in r: r[key] = number(r[key])
    window = config.get("age_window")
    if window: rows = [r for r in rows if r["idade"] is not None and window[0] <= r["idade"] <= window[1]]
    calendar = config.get("calendar")
    if calendar:
        eligible=[]
        for row in rows:
            day=as_date(row.get(calendar["column"]))
            if not day or day.year < calendar["min_year"]: continue
            if calendar.get("max_year")=="current" and day.year > reference.year: continue
            row[calendar["column"]]=day.isoformat()
            row["ano"]=str(day.year)
            eligible.append(row)
        rows=eligible
    return rows


def read_filters(request,config,action):
    extras = {"data_inicio","data_fim"}
    if action == "detalhes": extras |= {"pagina","tamanho","ordenar","direcao"}
    if set(request.query_params) - set(config["filters"]) - extras:
        raise HTTPException(422, detail="Parâmetro não configurado.")
    result = {}
    for key in config["filters"]:
        values = request.query_params.getlist(key)
        if len(values)>100 or any(len(v)>500 for v in values): raise HTTPException(422,detail="Limite de filtro excedido.")
        result[key] = list(dict.fromkeys(v.strip() for v in values if v.strip()))
    if "periodo_dias" in result and any(v not in {str(w) for w in config["weeks"]} for v in result["periodo_dias"]):
        raise HTTPException(422,detail="Semana inválida.")
    if "ano" in result and any(not re.fullmatch(r"[0-9]{4}",v) for v in result["ano"]):
        raise HTTPException(422,detail="Ano inválido.")
    return result


def match(row,filters,config,ignore=None,start=None,end=None):
    for key, values in filters.items():
        if key == ignore or not values: continue
        if key == "periodo_dias":
            if len(values)<len(config["weeks"]) and not any(row.get("idade",-1)>=int(v) for v in values): return False
        elif text(row.get(key)) not in values: return False
    if start or end:
        calendar = as_date(row.get("data") or row.get("abate") or row.get("recepcao"))
        if not calendar or (start and calendar<start) or (end and calendar>end): return False
    return True


def weekly(rows,config,weeks):
    points=[]
    for w in weeks:
        eligible=[r for r in rows if not config.get("age_window") or r.get("idade",-1)>=w]
        mortality_count=sum_column(eligible,f"mort{w}")
        discard_count=sum_column(eligible,f"disc{w}")
        deaths=mortality_count+discard_count
        birds=sum_column(eligible,"aves")
        points.append({"idade":w,"mortes":deaths,"mortalidade":ratio(deaths,birds,100),"mortalidade_sem_descartes":ratio(mortality_count,birds,100),"descarte_percent":ratio(discard_count,birds,100),"peso":mean([number(r.get(f"peso{w}")) for r in eligible]),"lotes":len(eligible)})
    return points


def stats(rows,config,weeks):
    if config.get("summary"):
        out={}
        for key,spec in config["summary"].items():
            col=spec["column"]
            if spec["aggregation"] == "sum": out[key]=sum_column(rows,col)
            elif spec["aggregation"] == "count_nonzero": out[key]=sum(1 for r in rows if number(r.get(col)) not in (None,Decimal(0)))
            else: raise ValueError("Agregação não configurada.")
        rate=config.get("ratio")
        if rate: out[rate["id"]]=ratio(out[rate["numerator"]],out[rate["denominator"]],rate["scale"])
        return out
    birds=sum_column(rows,"aves")
    points=weekly(rows,config,weeks)
    deaths=sum((p["mortes"] for p in points),Decimal(0))
    current=[]
    for r in rows:
        weight=number(r.get("peso_abate"))
        if weight is None:
            weight=next((number(r.get(f"peso{w}"))/1000 for w in reversed(weeks) if number(r.get(f"peso{w}")) is not None),None)
        current.append(weight)
    return {"lotes":len(rows),"aves":birds,"mortes":deaths,"mortalidade":ratio(deaths,birds,100),
            "peso":mean([p["peso"] for p in points]),"peso_atual":mean(current)}


def groups(rows,keys,config,weeks):
    grouped=defaultdict(list)
    for r in rows: grouped[tuple(text(r.get(k)) for k in keys)].append(r)
    result=[]
    for key,items in sorted(grouped.items()):
        group={**dict(zip(keys,key)),"key":json.dumps(key,ensure_ascii=False),"cards":stats(items,config,weeks),"weekly":weekly(items,config,weeks) if config["engine"]=="cohort" else []}
        if config["engine"]=="cohort":
            group["idade_atual"]=max((r["idade"] for r in items if r.get("idade") is not None),default=None)
            group["linhagens"]=sorted({text(r.get("linhagem")) for r in items if text(r.get("linhagem"))})
        result.append(group)
    return result


def hierarchy(rows,keys,config,weeks):
    if not keys: return []
    key=keys[0]
    parts=defaultdict(list)
    for row in rows: parts[text(row.get(key))].append(row)
    return [{"campo":key,"valor":value,"cards":stats(items,config,weeks),
             "weekly":weekly(items,config,weeks),"children":hierarchy(items,keys[1:],config,weeks)}
            for value,items in sorted(parts.items())]


def query_payload(config,request,banco,action):
    filters=read_filters(request,config,action)
    reference=datetime.now(ZoneInfo("America/Sao_Paulo")).date()
    start=as_date(request.query_params.get("data_inicio"))
    end=as_date(request.query_params.get("data_fim"))
    with banco() as conn: rows=prepare_rows(conn,config,reference)
    meta={"rules_version":config["rules_version"],"data_referencia":reference.isoformat(),
          "fontes":[s["table"] for s in config.get("sources",[])] or [config["table"]],
          "atualizado_em":max((text(r.get("atualizado")) for r in rows),default=None)}
    if action=="filtros":
        options={}
        for key in config["filters"]:
            available=[r for r in rows if match(r,filters,config,ignore=key,start=start,end=end)]
            if key=="periodo_dias": options[key]=[{"valor":str(w),"nome":f"{w} dias"} for w in config["weeks"] if any(r.get("idade",-1)>=w for r in available)]
            else: options[key]=sorted({text(r.get(key)) for r in available if text(r.get(key))},reverse=key in {"ano","data"})
        return options
    selected=[r for r in rows if match(r,filters,config,start=start,end=end)]
    weeks=[int(w) for w in filters.get("periodo_dias",[])] or config.get("weeks",[])
    cards=stats(selected,config,weeks)
    if action=="resumo":
        result={**meta,"filtros":filters,"cards":cards,"groups":groups(selected,config["group_by"],config,weeks)}
        if config["engine"]=="cohort":
            result["weekly"]=weekly(selected,config,weeks)
            result["pinto"]=mean([number(r.get("pinto")) for r in selected]) if set(weeks)==set(config["weeks"]) else None
            result["galpoes"]=groups(selected,["produtor","galpao"],config,weeks)
        if config.get("hierarchy"):
            result["hierarchy"] = hierarchy(selected,config["hierarchy"],config,weeks)
        return result
    def integer(key,default,maximum):
        values=request.query_params.getlist(key)
        try:
            if len(values)>1: raise ValueError()
            raw=values[0] if values else str(default)
            if not raw.isdigit(): raise ValueError()
            value=int(raw)
            if not 1<=value<=maximum: raise ValueError()
            return value
        except ValueError: raise HTTPException(422,detail="Paginação inválida.")
    page=integer("pagina",1,1000000);size=integer("tamanho",100,500)
    order=request.query_params.get("ordenar","id")
    direction=request.query_params.get("direcao","asc")
    allowed=set(config["columns"]) | {"unidade","tecnico"}
    if order not in allowed or direction not in {"asc","desc"}: raise HTTPException(422,detail="Ordenação inválida.")
    def sort_key(r):
        v=r.get(order)
        if order=="id": return (v is None,int(v or 0),text(r.get("fonte")))
        return (v is None,v if isinstance(v,Decimal) else text(v),text(r.get("fonte")),int(r.get("id") or 0))
    nonnull = [row for row in selected if row.get(order) is not None]
    missing = [row for row in selected if row.get(order) is None]
    nonnull.sort(key=sort_key,reverse=direction=="desc")
    missing.sort(key=lambda row: (text(row.get("fonte")), int(row.get("id") or 0)))
    selected = nonnull + missing
    total=len(selected)
    return {**meta,"filtros":filters,"cards":cards,"pagina":page,"tamanho":size,"total":total,
            "total_paginas":(total+size-1)//size,"dados":selected[(page-1)*size:page*size]}
