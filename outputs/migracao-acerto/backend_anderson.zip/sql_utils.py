"""Helpers SQL seguros para a camada genérica de BI."""
from datetime import date

from psycopg import sql

from .registry import MESES_PT


def _spec(value):
    if isinstance(value, str):
        return {"kind": "text", "column": value}
    return value


def texto(coluna):
    return sql.SQL("NULLIF(BTRIM({}::text), '')").format(sql.Identifier(coluna))


def ano_expr(coluna):
    c = texto(coluna)
    return sql.SQL(
        "CASE WHEN {c} ~ '^[0-9]{{4}}$' THEN {c}::integer ELSE NULL END"
    ).format(c=c)


def mes_expr(coluna):
    c = texto(coluna)
    return sql.SQL(
        """
        CASE
            WHEN {c} IS NULL THEN NULL
            WHEN lower({c}) IN ('1','01','jan','janeiro') THEN 1
            WHEN lower({c}) IN ('2','02','fev','fevereiro') THEN 2
            WHEN lower({c}) IN ('3','03','mar','marco','março') THEN 3
            WHEN lower({c}) IN ('4','04','abr','abril') THEN 4
            WHEN lower({c}) IN ('5','05','mai','maio') THEN 5
            WHEN lower({c}) IN ('6','06','jun','junho') THEN 6
            WHEN lower({c}) IN ('7','07','jul','julho') THEN 7
            WHEN lower({c}) IN ('8','08','ago','agosto') THEN 8
            WHEN lower({c}) IN ('9','09','set','setembro') THEN 9
            WHEN lower({c}) IN ('10','out','outubro') THEN 10
            WHEN lower({c}) IN ('11','nov','novembro') THEN 11
            WHEN lower({c}) IN ('12','dez','dezembro') THEN 12
            ELSE NULL
        END
        """
    ).format(c=c)


def tipo_linhagem_expr(coluna):
    c = texto(coluna)
    return sql.SQL(
        """
        CASE
            WHEN {c} IS NULL THEN NULL
            WHEN POSITION('/' IN {c}) > 0 THEN 'mista'
            ELSE 'pura'
        END
        """
    ).format(c=c)


def filtro_expr(filtro_config):
    spec = _spec(filtro_config)
    kind = spec.get("kind", "text")
    coluna = spec["column"]

    if kind in {"date_year", "date_month"}:
        component = "year" if kind == "date_year" else "month"
        return sql.SQL("EXTRACT({} FROM {})::integer").format(sql.SQL(component), (date_texto(coluna) if spec.get("date_kind", "text") == "text" else sql.SQL("{}::date").format(sql.Identifier(coluna))))
    if kind == "text":
        return texto(coluna)
    if kind in {"year", "date_year"}:
        return ano_expr(coluna)
    if kind in {"month", "date_month"}:
        return mes_expr(coluna)
    if kind == "lineage_type":
        return tipo_linhagem_expr(coluna)

    raise ValueError(f"Tipo de filtro não suportado: {kind}")


def _normalizar_mes(valor):
    raw = str(valor).strip().lower()
    aliases = {
        "1": 1, "01": 1, "jan": 1, "janeiro": 1,
        "2": 2, "02": 2, "fev": 2, "fevereiro": 2,
        "3": 3, "03": 3, "mar": 3, "marco": 3, "março": 3,
        "4": 4, "04": 4, "abr": 4, "abril": 4,
        "5": 5, "05": 5, "mai": 5, "maio": 5,
        "6": 6, "06": 6, "jun": 6, "junho": 6,
        "7": 7, "07": 7, "jul": 7, "julho": 7,
        "8": 8, "08": 8, "ago": 8, "agosto": 8,
        "9": 9, "09": 9, "set": 9, "setembro": 9,
        "10": 10, "out": 10, "outubro": 10,
        "11": 11, "nov": 11, "novembro": 11,
        "12": 12, "dez": 12, "dezembro": 12,
    }
    return aliases.get(raw)


def normalizar_valores(filtro_config, valores):
    spec = _spec(filtro_config)
    kind = spec.get("kind", "text")
    resultado = []

    for valor in valores or []:
        if valor is None:
            continue
        raw = str(valor).strip()
        if not raw:
            continue

        if kind in {"year", "date_year"}:
            if raw.isdigit() and len(raw) == 4:
                resultado.append(int(raw))
            continue

        if kind in {"month", "date_month"}:
            mes = _normalizar_mes(raw)
            if mes is not None:
                resultado.append(mes)
            continue

        if kind == "lineage_type":
            lower = raw.lower()
            if lower in {"pura", "mista"}:
                resultado.append(lower)
            continue

        resultado.append(raw)

    return list(dict.fromkeys(resultado))


def numeric_texto(coluna):
    """Conversão compatível com o backend legado: ponto ou vírgula decimal."""
    c = texto(coluna)
    return sql.SQL(
        "CASE WHEN {c} ~ '^[+-]?[0-9]+([.,][0-9]+)?$' "
        "THEN replace({c}, ',', '.')::numeric ELSE NULL END"
    ).format(c=c)


def numeric_typed(coluna):
    c = sql.Identifier(coluna)
    return sql.SQL("CASE WHEN {c}::text NOT IN ('NaN','Infinity','-Infinity') THEN {c}::numeric ELSE NULL END").format(c=c)


def metrica_valor_expr(metrica):
    number = numeric_typed if metrica.get("numeric_kind") == "typed" else numeric_texto
    formula = metrica.get("formula")
    if formula:
        numerator = number(formula["numerator"])
        denominator = number(formula["denominator"])
        if formula.get("multiply"):
            numerator = sql.SQL("({}) * ({})").format(numerator, number(formula["multiply"]))
        return sql.SQL("(({n}) / NULLIF(({d}), 0)) * {scale}").format(n=numerator,d=denominator,scale=sql.Literal(formula.get("scale",1)))
    return number(metrica["column"])


def metrica_expr(metrica):
    valor = metrica_valor_expr(metrica)
    if "replace_outside" in metrica:
        low, high, substitute = metrica["replace_outside"]
        valor = sql.SQL("CASE WHEN ({v}) < {lo} OR ({v}) > {hi} THEN {sub} ELSE ({v}) END").format(
            v=valor, lo=sql.Literal(low), hi=sql.Literal(high), sub=sql.Literal(substitute))
    if "replace_above" in metrica:
        high, substitute = metrica["replace_above"]
        valor = sql.SQL("CASE WHEN ({v}) > {hi} THEN {sub} ELSE ({v}) END").format(v=valor,hi=sql.Literal(high),sub=sql.Literal(substitute))
    aggregation = metrica["aggregation"]
    if aggregation == "avg":
        return sql.SQL("AVG({})").format(valor)
    if aggregation == "sum":
        return sql.SQL("SUM({})").format(valor)
    if aggregation == "weighted_avg":
        peso = numeric_texto(metrica["weight"])
        if metrica.get("null_policy") == "valid_pairs":
            return sql.SQL("SUM(({v}) * ({p})) / NULLIF(SUM(CASE WHEN ({v}) IS NOT NULL AND ({p}) IS NOT NULL THEN ({p}) END), 0)").format(v=valor,p=peso)
        return sql.SQL("SUM(({v}) * ({p})) / NULLIF(SUM({p}), 0)").format(v=valor,p=peso)
    raise ValueError(f"Agregação não suportada: {aggregation}")


def _date_value(value):
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        return date.fromisoformat(raw)
    except ValueError:
        return None


def condicoes(config, selecionados, ignorar=None, data_inicio=None, data_fim=None):
    partes = []
    valores = []

    # Regra global já usada pelo BI legado.
    ano = filtro_expr(config["filters"]["ano"])
    mes = filtro_expr(config["filters"]["mes"])
    partes.append(sql.SQL("{} >= %s").format(ano))
    valores.append(int(config.get("min_year", 2023)))
    # O BI legado derivava ano/mês de uma data válida; manter mês válido
    # preserva o mesmo universo de registros para filtros e cálculos.
    partes.append(sql.SQL("{} IS NOT NULL").format(mes))

    for nome, filtro_config in config["filters"].items():
        if nome == ignorar:
            continue

        escolhas = normalizar_valores(
            filtro_config,
            selecionados.get(nome, []),
        )
        if not escolhas:
            continue

        expr = filtro_expr(filtro_config)
        placeholders = sql.SQL(", ").join(
            sql.Placeholder() for _ in escolhas
        )
        partes.append(sql.SQL("{} IN ({})").format(expr, placeholders))
        valores.extend(escolhas)

    data_col = config.get("date_column")
    if data_col:
        date_expr = date_texto(data_col) if config.get("date_kind") == "text" else sql.SQL("{}::date").format(sql.Identifier(data_col))
        inicio = _date_value(data_inicio)
        fim = _date_value(data_fim)

        if inicio is not None:
            partes.append(sql.SQL("{} >= %s").format(date_expr))
            valores.append(inicio)
        if fim is not None:
            partes.append(sql.SQL("{} <= %s").format(date_expr))
            valores.append(fim)

    return partes, valores


def where_sql(partes):
    if not partes:
        return sql.SQL("")
    return sql.SQL(" WHERE ") + sql.SQL(" AND ").join(partes)


def query_opcoes(config, selecionados, filtro, data_inicio=None, data_fim=None):
    filtro_config = config["filters"][filtro]
    expr = filtro_expr(filtro_config)
    partes, valores = condicoes(
        config,
        selecionados,
        ignorar=filtro,
        data_inicio=data_inicio,
        data_fim=data_fim,
    )
    partes.append(sql.SQL("{} IS NOT NULL").format(expr))

    ordem = _spec(filtro_config).get("order", "asc").lower()
    direction = sql.SQL("DESC") if ordem == "desc" else sql.SQL("ASC")

    consulta = sql.SQL(
        "SELECT DISTINCT {expr} AS valor "
        "FROM {table}{where} ORDER BY valor {direction}"
    ).format(
        expr=expr,
        table=sql.Identifier(config["schema"], config["table"]),
        where=where_sql(partes),
        direction=direction,
    )
    return consulta, valores


def meses_publicos(valores):
    resultado = []
    for valor in valores:
        try:
            numero = int(valor)
        except (TypeError, ValueError):
            continue
        if 1 <= numero <= 12:
            resultado.append({
                "valor": numero,
                "nome": MESES_PT[numero - 1],
            })
    return resultado


def tipo_linhagem_publico(valores):
    nomes = {"pura": "Pura", "mista": "Mista"}
    return [
        {"valor": str(valor), "nome": nomes.get(str(valor), str(valor))}
        for valor in valores
        if valor is not None
    ]


def date_texto(coluna):
    """ISO (com horário opcional) ou dd/mm/yyyy; datas impossíveis viram NULL.

    Valida componentes antes de make_date, sem CAST direto de texto recebido.
    """
    c = texto(coluna)
    iso = sql.SQL("{c} ~ '^[0-9]{{4}}-[0-9]{{2}}-[0-9]{{2}}([ T].*)?$'").format(c=c)
    br = sql.SQL("{c} ~ '^[0-9]{{2}}/[0-9]{{2}}/[0-9]{{4}}$'").format(c=c)
    def part(start, length):
        return sql.SQL("substring({c} from {s} for {n})::integer").format(c=c,s=sql.Literal(start),n=sql.Literal(length))
    def valid_date(y,m,d):
        return sql.SQL("CASE WHEN {y} BETWEEN 1 AND 9999 AND {m} BETWEEN 1 AND 12 THEN CASE WHEN {d} BETWEEN 1 AND EXTRACT(day FROM (make_date({y},{m},1) + interval '1 month - 1 day')) THEN make_date({y},{m},{d}) ELSE NULL END ELSE NULL END").format(y=y,m=m,d=d)
    return sql.SQL("CASE WHEN {iso} THEN {a} WHEN {br} THEN {b} ELSE NULL END").format(
        iso=iso,br=br,a=valid_date(part(1,4),part(6,2),part(9,2)),b=valid_date(part(7,4),part(4,2),part(1,2)))
